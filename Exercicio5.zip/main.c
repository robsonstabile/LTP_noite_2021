#include <stdio.h>
#include <math.h>

int main(void) {
  float entrada_v , entrada_i , saida_r;

  printf("Entre com o valor da tensão [V]:\n ");
  scanf("%f" , &entrada_v);

  printf("Entre com o valor da corrente [I]:\n");
  scanf("%f" , &entrada_i);

  saida_r = entrada_v / entrada_i ;

  printf("Valor da Resistencia em [ohms]: %.2f\n",saida_r);
  return 0;
}